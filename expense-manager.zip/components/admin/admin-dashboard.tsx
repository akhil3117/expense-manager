"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UsersManagement } from "./users-management"
import { ApprovalFlowManagement } from "./approval-flow-management"
import { ExpensesOverview } from "./expenses-overview"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"

interface AdminDashboardProps {
  profile: any
  users: any[]
  categories: any[]
  approvalFlows: any[]
  approvalRules: any[]
  expenses: any[]
}

export function AdminDashboard({
  profile,
  users,
  categories,
  approvalFlows,
  approvalRules,
  expenses,
}: AdminDashboardProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader profile={profile} />

      <main className="flex-1 p-6">
        <div className="mx-auto max-w-7xl space-y-6">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage users, approval flows, and company settings</p>
          </div>

          <Tabs defaultValue="users" className="space-y-6">
            <TabsList>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="approval-flows">Approval Flows</TabsTrigger>
              <TabsTrigger value="expenses">All Expenses</TabsTrigger>
            </TabsList>

            <TabsContent value="users" className="space-y-4">
              <UsersManagement users={users} companyId={profile.company_id} />
            </TabsContent>

            <TabsContent value="approval-flows" className="space-y-4">
              <ApprovalFlowManagement
                users={users}
                approvalFlows={approvalFlows}
                approvalRules={approvalRules}
                companyId={profile.company_id}
              />
            </TabsContent>

            <TabsContent value="expenses" className="space-y-4">
              <ExpensesOverview expenses={expenses} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
