"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

interface AddApprovalFlowDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  companyId: string
  users: any[]
  existingFlows: any[]
}

export function AddApprovalFlowDialog({
  open,
  onOpenChange,
  companyId,
  users,
  existingFlows,
}: AddApprovalFlowDialogProps) {
  const [approverId, setApproverId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    // Get next sequence order
    const nextOrder = existingFlows.length + 1

    const { error } = await supabase.from("approval_flows").insert({
      company_id: companyId,
      approver_id: approverId,
      sequence_order: nextOrder,
    })

    if (error) {
      alert("Error adding approver: " + error.message)
      setIsLoading(false)
      return
    }

    setIsLoading(false)
    setApproverId("")
    onOpenChange(false)
    router.refresh()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Approver to Flow</DialogTitle>
          <DialogDescription>Add a new step to the sequential approval process</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="approver">Approver</Label>
            <Select value={approverId} onValueChange={setApproverId} required>
              <SelectTrigger>
                <SelectValue placeholder="Select approver" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.full_name || user.email} ({user.role})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              This approver will be added as Step {existingFlows.length + 1}
            </p>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !approverId}>
              {isLoading ? "Adding..." : "Add Approver"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
