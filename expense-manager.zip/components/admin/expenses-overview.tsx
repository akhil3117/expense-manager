"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { formatDate } from "@/lib/utils"
import { useEffect, useState } from "react"
import { formatCurrencyWithConversion, type ExchangeRates } from "@/lib/currency"

interface ExpensesOverviewProps {
  expenses: any[]
}

export function ExpensesOverview({ expenses }: ExpensesOverviewProps) {
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates | null>(null)
  const baseCurrency = "USD" // This could come from company settings

  useEffect(() => {
    // Fetch exchange rates
    fetch(`/api/exchange-rates?base=${baseCurrency}`)
      .then((res) => res.json())
      .then((data) => setExchangeRates(data))
      .catch((err) => console.error("Failed to fetch exchange rates:", err))
  }, [baseCurrency])

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "secondary"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Expenses</CardTitle>
        <CardDescription>Overview of all expense submissions across the company</CardDescription>
      </CardHeader>
      <CardContent>
        {expenses.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No expenses submitted yet</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {expenses.map((expense) => (
                <TableRow key={expense.id}>
                  <TableCell className="font-medium">{expense.profiles?.full_name || "N/A"}</TableCell>
                  <TableCell>
                    {formatCurrencyWithConversion(expense.amount, expense.currency, baseCurrency, exchangeRates)}
                  </TableCell>
                  <TableCell>{expense.expense_categories?.name || "N/A"}</TableCell>
                  <TableCell>{formatDate(expense.expense_date)}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(expense.status)}>{expense.status}</Badge>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">{expense.description || "-"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
