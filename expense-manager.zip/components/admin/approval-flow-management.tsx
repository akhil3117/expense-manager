"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react"
import { AddApprovalFlowDialog } from "./add-approval-flow-dialog"
import { AddApprovalRuleDialog } from "./add-approval-rule-dialog"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

interface ApprovalFlowManagementProps {
  users: any[]
  approvalFlows: any[]
  approvalRules: any[]
  companyId: string
}

export function ApprovalFlowManagement({
  users,
  approvalFlows,
  approvalRules,
  companyId,
}: ApprovalFlowManagementProps) {
  const [isFlowDialogOpen, setIsFlowDialogOpen] = useState(false)
  const [isRuleDialogOpen, setIsRuleDialogOpen] = useState(false)
  const router = useRouter()

  const handleDeleteFlow = async (flowId: string) => {
    if (!confirm("Are you sure you want to delete this approval flow?")) return

    const supabase = createClient()
    const { error } = await supabase.from("approval_flows").delete().eq("id", flowId)

    if (error) {
      alert("Error deleting flow: " + error.message)
    } else {
      router.refresh()
    }
  }

  const handleDeleteRule = async (ruleId: string) => {
    if (!confirm("Are you sure you want to delete this approval rule?")) return

    const supabase = createClient()
    const { error } = await supabase.from("approval_rules").delete().eq("id", ruleId)

    if (error) {
      alert("Error deleting rule: " + error.message)
    } else {
      router.refresh()
    }
  }

  const handleMoveFlow = async (flowId: string, direction: "up" | "down") => {
    const supabase = createClient()
    const currentFlow = approvalFlows.find((f) => f.id === flowId)
    if (!currentFlow) return

    const currentOrder = currentFlow.sequence_order
    const targetOrder = direction === "up" ? currentOrder - 1 : currentOrder + 1
    const targetFlow = approvalFlows.find((f) => f.sequence_order === targetOrder)

    if (!targetFlow) return

    // Swap orders
    await supabase.from("approval_flows").update({ sequence_order: targetOrder }).eq("id", flowId)

    await supabase.from("approval_flows").update({ sequence_order: currentOrder }).eq("id", targetFlow.id)

    router.refresh()
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Sequential Approval Flow</CardTitle>
              <CardDescription>Define the order of approvers for expense requests</CardDescription>
            </div>
            <Button onClick={() => setIsFlowDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Approver
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {approvalFlows.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No approval flow configured. Add approvers to create a sequential approval process.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Step</TableHead>
                  <TableHead>Approver</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {approvalFlows.map((flow, index) => (
                  <TableRow key={flow.id}>
                    <TableCell>
                      <Badge variant="outline">Step {flow.sequence_order}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">{flow.profiles?.full_name || "N/A"}</TableCell>
                    <TableCell>{flow.profiles?.email}</TableCell>
                    <TableCell>
                      <Badge>{flow.profiles?.role}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleMoveFlow(flow.id, "up")}
                          disabled={index === 0}
                        >
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleMoveFlow(flow.id, "down")}
                          disabled={index === approvalFlows.length - 1}
                        >
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteFlow(flow.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Conditional Approval Rules</CardTitle>
              <CardDescription>Set percentage-based or specific approver rules</CardDescription>
            </div>
            <Button onClick={() => setIsRuleDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Rule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {approvalRules.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No conditional rules configured. Add rules for flexible approval workflows.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Rule Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Configuration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {approvalRules.map((rule) => (
                  <TableRow key={rule.id}>
                    <TableCell className="font-medium">{rule.name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{rule.rule_type.replace("_", " ")}</Badge>
                    </TableCell>
                    <TableCell>
                      {rule.rule_type === "percentage" && `${rule.percentage_threshold}% approval required`}
                      {rule.rule_type === "specific_approver" && `${rule.profiles?.full_name || "N/A"} must approve`}
                      {rule.rule_type === "hybrid" &&
                        `${rule.percentage_threshold}% OR ${rule.profiles?.full_name || "N/A"}`}
                    </TableCell>
                    <TableCell>
                      {rule.is_active ? (
                        <Badge variant="default">Active</Badge>
                      ) : (
                        <Badge variant="outline">Inactive</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteRule(rule.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <AddApprovalFlowDialog
        open={isFlowDialogOpen}
        onOpenChange={setIsFlowDialogOpen}
        companyId={companyId}
        users={users.filter((u) => u.role === "manager" || u.role === "admin")}
        existingFlows={approvalFlows}
      />

      <AddApprovalRuleDialog
        open={isRuleDialogOpen}
        onOpenChange={setIsRuleDialogOpen}
        companyId={companyId}
        users={users.filter((u) => u.role === "manager" || u.role === "admin")}
      />
    </div>
  )
}
