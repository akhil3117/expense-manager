"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

interface AddApprovalRuleDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  companyId: string
  users: any[]
}

export function AddApprovalRuleDialog({ open, onOpenChange, companyId, users }: AddApprovalRuleDialogProps) {
  const [name, setName] = useState("")
  const [ruleType, setRuleType] = useState<"percentage" | "specific_approver" | "hybrid">("percentage")
  const [percentage, setPercentage] = useState("60")
  const [approverId, setApproverId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    const { error } = await supabase.from("approval_rules").insert({
      company_id: companyId,
      name,
      rule_type: ruleType,
      percentage_threshold: ruleType === "percentage" || ruleType === "hybrid" ? Number.parseInt(percentage) : null,
      specific_approver_id: ruleType === "specific_approver" || ruleType === "hybrid" ? approverId : null,
      is_active: true,
    })

    if (error) {
      alert("Error adding rule: " + error.message)
      setIsLoading(false)
      return
    }

    setIsLoading(false)
    setName("")
    setRuleType("percentage")
    setPercentage("60")
    setApproverId("")
    onOpenChange(false)
    router.refresh()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Approval Rule</DialogTitle>
          <DialogDescription>Create a conditional approval rule for flexible workflows</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Rule Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., CFO Override Rule"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ruleType">Rule Type</Label>
            <Select value={ruleType} onValueChange={(v: any) => setRuleType(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="percentage">Percentage Based</SelectItem>
                <SelectItem value="specific_approver">Specific Approver</SelectItem>
                <SelectItem value="hybrid">Hybrid (Both)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {(ruleType === "percentage" || ruleType === "hybrid") && (
            <div className="space-y-2">
              <Label htmlFor="percentage">Approval Percentage</Label>
              <Input
                id="percentage"
                type="number"
                min="1"
                max="100"
                value={percentage}
                onChange={(e) => setPercentage(e.target.value)}
                required
              />
              <p className="text-sm text-muted-foreground">
                Expense is approved if this percentage of approvers approve
              </p>
            </div>
          )}
          {(ruleType === "specific_approver" || ruleType === "hybrid") && (
            <div className="space-y-2">
              <Label htmlFor="approver">Specific Approver</Label>
              <Select value={approverId} onValueChange={setApproverId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select approver" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.full_name || user.email} ({user.role})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">Expense is auto-approved if this person approves</p>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Creating..." : "Create Rule"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
