"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Upload } from "lucide-react"

interface SubmitExpenseFormProps {
  employeeId: string
  companyId: string
  categories: any[]
  managerId: string | null
  isManagerApprover: boolean
}

export function SubmitExpenseForm({
  employeeId,
  companyId,
  categories,
  managerId,
  isManagerApprover,
}: SubmitExpenseFormProps) {
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState("USD")
  const [categoryId, setCategoryId] = useState("")
  const [description, setDescription] = useState("")
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split("T")[0])
  const [receiptFile, setReceiptFile] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceiptFile(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      // Upload receipt if provided
      let receiptUrl = null
      if (receiptFile) {
        const fileExt = receiptFile.name.split(".").pop()
        const fileName = `${employeeId}/${Date.now()}.${fileExt}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("receipts")
          .upload(fileName, receiptFile)

        if (uploadError) throw uploadError

        const { data: urlData } = supabase.storage.from("receipts").getPublicUrl(fileName)
        receiptUrl = urlData.publicUrl
      }

      // Create expense
      const { data: expense, error: expenseError } = await supabase
        .from("expenses")
        .insert({
          employee_id: employeeId,
          company_id: companyId,
          amount: Number.parseFloat(amount),
          currency,
          category_id: categoryId,
          description,
          expense_date: expenseDate,
          receipt_url: receiptUrl,
          status: "pending",
        })
        .select()
        .single()

      if (expenseError) throw expenseError

      // Create initial approval record for manager if required
      if (isManagerApprover && managerId) {
        await supabase.from("expense_approvals").insert({
          expense_id: expense.id,
          approver_id: managerId,
          status: "pending",
          is_manager_approval: true,
        })
      } else {
        // Get approval flow and create approval records
        const { data: approvalFlows } = await supabase
          .from("approval_flows")
          .select("*")
          .eq("company_id", companyId)
          .order("sequence_order", { ascending: true })

        if (approvalFlows && approvalFlows.length > 0) {
          const approvalRecords = approvalFlows.map((flow) => ({
            expense_id: expense.id,
            approver_id: flow.approver_id,
            status: "pending",
            sequence_order: flow.sequence_order,
          }))

          await supabase.from("expense_approvals").insert(approvalRecords)
        }
      }

      // Reset form
      setAmount("")
      setCurrency("USD")
      setCategoryId("")
      setDescription("")
      setExpenseDate(new Date().toISOString().split("T")[0])
      setReceiptFile(null)

      alert("Expense submitted successfully!")
      router.refresh()
    } catch (error: any) {
      alert("Error submitting expense: " + error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Submit New Expense</CardTitle>
        <CardDescription>Fill in the details of your expense request</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                  <SelectItem value="CAD">CAD</SelectItem>
                  <SelectItem value="AUD">AUD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={categoryId} onValueChange={setCategoryId} required>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="expenseDate">Expense Date</Label>
            <Input
              id="expenseDate"
              type="date"
              value={expenseDate}
              onChange={(e) => setExpenseDate(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide details about this expense..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="receipt">Receipt (Optional)</Label>
            <div className="flex items-center gap-2">
              <Input id="receipt" type="file" accept="image/*,.pdf" onChange={handleFileChange} className="flex-1" />
              {receiptFile && (
                <span className="text-sm text-muted-foreground">
                  <Upload className="inline h-4 w-4 mr-1" />
                  {receiptFile.name}
                </span>
              )}
            </div>
          </div>

          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? "Submitting..." : "Submit Expense"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
