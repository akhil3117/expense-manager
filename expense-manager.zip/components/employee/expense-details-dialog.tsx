"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { formatDate, formatCurrency } from "@/lib/utils"
import { CheckCircle2, XCircle, Clock, FileText } from "lucide-react"

interface ExpenseDetailsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  expense: any
}

export function ExpenseDetailsDialog({ open, onOpenChange, expense }: ExpenseDetailsDialogProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle2 className="h-4 w-4 text-green-600" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "secondary"
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Expense Details</DialogTitle>
          <DialogDescription>Complete information about this expense request</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Amount</p>
              <p className="text-2xl font-bold">{formatCurrency(expense.amount, expense.currency)}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Status</p>
              <Badge variant={getStatusBadgeVariant(expense.status)} className="mt-1">
                {expense.status}
              </Badge>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Category</p>
              <p className="text-base">{expense.expense_categories?.name || "N/A"}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Date</p>
              <p className="text-base">{formatDate(expense.expense_date)}</p>
            </div>
          </div>

          {expense.description && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">Description</p>
              <p className="text-base">{expense.description}</p>
            </div>
          )}

          {expense.receipt_url && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2">Receipt</p>
              <a
                href={expense.receipt_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-sm text-primary hover:underline"
              >
                <FileText className="mr-2 h-4 w-4" />
                View Receipt
              </a>
            </div>
          )}

          <Separator />

          {/* Approval Timeline */}
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3">Approval Timeline</p>
            {expense.expense_approvals && expense.expense_approvals.length > 0 ? (
              <div className="space-y-3">
                {expense.expense_approvals.map((approval: any, index: number) => (
                  <div key={approval.id} className="flex items-start gap-3">
                    <div className="mt-1">{getStatusIcon(approval.status)}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">
                          {approval.is_manager_approval
                            ? "Manager Approval"
                            : `Step ${approval.sequence_order || index + 1}`}
                        </p>
                        <Badge variant="outline" className="text-xs">
                          {approval.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {approval.profiles?.full_name || approval.profiles?.email || "N/A"}
                      </p>
                      {approval.comments && (
                        <p className="text-sm text-muted-foreground mt-1 italic">"{approval.comments}"</p>
                      )}
                      {approval.approved_at && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {approval.status === "approved" ? "Approved" : "Rejected"} on{" "}
                          {formatDate(approval.approved_at)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No approval records found</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
