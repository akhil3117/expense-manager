"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SubmitExpenseForm } from "./submit-expense-form"
import { ExpenseHistory } from "./expense-history"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"

interface EmployeeDashboardProps {
  profile: any
  categories: any[]
  expenses: any[]
}

export function EmployeeDashboard({ profile, categories, expenses }: EmployeeDashboardProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader profile={profile} />

      <main className="flex-1 p-6">
        <div className="mx-auto max-w-7xl space-y-6">
          <div>
            <h1 className="text-3xl font-bold">My Expenses</h1>
            <p className="text-muted-foreground">Submit and track your expense requests</p>
          </div>

          <Tabs defaultValue="submit" className="space-y-6">
            <TabsList>
              <TabsTrigger value="submit">Submit Expense</TabsTrigger>
              <TabsTrigger value="history">My History</TabsTrigger>
            </TabsList>

            <TabsContent value="submit" className="space-y-4">
              <SubmitExpenseForm
                employeeId={profile.id}
                companyId={profile.company_id}
                categories={categories}
                managerId={profile.manager_id}
                isManagerApprover={profile.is_manager_approver}
              />
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              <ExpenseHistory expenses={expenses} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
