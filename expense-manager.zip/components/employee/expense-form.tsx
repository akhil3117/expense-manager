"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Scan, Loader2 } from "lucide-react"
import { extractReceiptData } from "@/lib/ocr"

interface ExpenseFormProps {
  categories: any[]
  userId: string
}

export function ExpenseForm({ categories, userId }: ExpenseFormProps) {
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState("USD")
  const [categoryId, setCategoryId] = useState("")
  const [description, setDescription] = useState("")
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split("T")[0])
  const [receiptFile, setReceiptFile] = useState<File | null>(null)
  const [receiptUrl, setReceiptUrl] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isScanning, setIsScanning] = useState(false)
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceiptFile(e.target.files[0])
    }
  }

  const handleScanReceipt = async () => {
    if (!receiptFile) {
      alert("Please upload a receipt first")
      return
    }

    setIsScanning(true)

    try {
      const supabase = createClient()

      // Upload the receipt to get a URL
      const fileExt = receiptFile.name.split(".").pop()
      const fileName = `${userId}-${Date.now()}.${fileExt}`
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("receipts")
        .upload(fileName, receiptFile)

      if (uploadError) throw uploadError

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from("receipts").getPublicUrl(fileName)

      setReceiptUrl(publicUrl)

      // Extract data from receipt using OCR
      const receiptData = await extractReceiptData(publicUrl)

      // Auto-fill form fields
      if (receiptData.amount) setAmount(receiptData.amount.toString())
      if (receiptData.currency) setCurrency(receiptData.currency)
      if (receiptData.date) setExpenseDate(receiptData.date)
      if (receiptData.category) {
        // Try to match category
        const matchedCategory = categories.find((cat) => cat.name.toLowerCase() === receiptData.category?.toLowerCase())
        if (matchedCategory) setCategoryId(matchedCategory.id)
      }
      if (receiptData.merchant || receiptData.items) {
        let desc = ""
        if (receiptData.merchant) desc += `Merchant: ${receiptData.merchant}\n`
        if (receiptData.items && receiptData.items.length > 0) {
          desc += `Items: ${receiptData.items.join(", ")}`
        }
        setDescription(desc.trim())
      }

      alert("Receipt scanned successfully! Please review the extracted information.")
    } catch (error: any) {
      alert("Error scanning receipt: " + error.message)
    } finally {
      setIsScanning(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      let finalReceiptUrl = receiptUrl

      // Upload receipt if not already uploaded
      if (receiptFile && !receiptUrl) {
        const fileExt = receiptFile.name.split(".").pop()
        const fileName = `${userId}-${Date.now()}.${fileExt}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("receipts")
          .upload(fileName, receiptFile)

        if (uploadError) throw uploadError

        const {
          data: { publicUrl },
        } = supabase.storage.from("receipts").getPublicUrl(fileName)
        finalReceiptUrl = publicUrl
      }

      // Create expense
      const { data: expense, error: expenseError } = await supabase
        .from("expenses")
        .insert({
          user_id: userId,
          amount: Number.parseFloat(amount),
          currency,
          category_id: categoryId,
          description,
          expense_date: expenseDate,
          receipt_url: finalReceiptUrl,
          status: "pending",
        })
        .select()
        .single()

      if (expenseError) throw expenseError

      // Get user's company and manager
      const { data: profile } = await supabase
        .from("profiles")
        .select("company_id, manager_id")
        .eq("id", userId)
        .single()

      if (profile?.company_id) {
        // Check for approval rules
        const { data: approvalRules } = await supabase
          .from("approval_rules")
          .select("*")
          .eq("company_id", profile.company_id)
          .eq("is_active", true)
          .order("sequence_order", { ascending: true })

        if (approvalRules && approvalRules.length > 0) {
          // Create approval records based on rules
          const approvals = []

          for (const rule of approvalRules) {
            // Check if rule applies to this expense
            let applies = true

            if (rule.min_amount && Number.parseFloat(amount) < rule.min_amount) applies = false
            if (rule.max_amount && Number.parseFloat(amount) > rule.max_amount) applies = false
            if (rule.category_id && rule.category_id !== categoryId) applies = false

            if (applies) {
              if (rule.rule_type === "specific_approver" && rule.specific_approver_id) {
                approvals.push({
                  expense_id: expense.id,
                  approver_id: rule.specific_approver_id,
                  sequence_order: rule.sequence_order,
                  status: "pending",
                  is_manager_approval: false,
                })
              } else if (rule.rule_type === "manager" && profile.manager_id) {
                approvals.push({
                  expense_id: expense.id,
                  approver_id: profile.manager_id,
                  sequence_order: rule.sequence_order,
                  status: "pending",
                  is_manager_approval: true,
                })
              }
            }
          }

          if (approvals.length > 0) {
            await supabase.from("expense_approvals").insert(approvals)
          }
        } else if (profile.manager_id) {
          // Default: require manager approval
          await supabase.from("expense_approvals").insert({
            expense_id: expense.id,
            approver_id: profile.manager_id,
            sequence_order: 1,
            status: "pending",
            is_manager_approval: true,
          })
        }
      }

      // Reset form
      setAmount("")
      setCurrency("USD")
      setCategoryId("")
      setDescription("")
      setExpenseDate(new Date().toISOString().split("T")[0])
      setReceiptFile(null)
      setReceiptUrl("")

      router.refresh()
      alert("Expense submitted successfully!")
    } catch (error: any) {
      alert("Error submitting expense: " + error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Submit New Expense</CardTitle>
        <CardDescription>Upload a receipt and fill in the expense details</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="receipt">Receipt</Label>
            <div className="flex gap-2">
              <Input
                id="receipt"
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="flex-1"
                disabled={isScanning}
              />
              <Button
                type="button"
                variant="secondary"
                onClick={handleScanReceipt}
                disabled={!receiptFile || isScanning}
                className="shrink-0"
              >
                {isScanning ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Scan className="mr-2 h-4 w-4" />
                    Scan Receipt
                  </>
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Upload a receipt image and click "Scan Receipt" to auto-fill the form
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency *</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger id="currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                  <SelectItem value="CAD">CAD</SelectItem>
                  <SelectItem value="AUD">AUD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Expense Date *</Label>
              <Input
                id="date"
                type="date"
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add any additional details..."
              rows={3}
            />
          </div>

          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? "Submitting..." : "Submit Expense"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
