"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Eye } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { useState, useEffect } from "react"
import { ExpenseDetailsDialog } from "./expense-details-dialog"
import { formatCurrencyWithConversion, type ExchangeRates } from "@/lib/currency"

interface ExpenseHistoryProps {
  expenses: any[]
}

export function ExpenseHistory({ expenses }: ExpenseHistoryProps) {
  const [selectedExpense, setSelectedExpense] = useState<any>(null)
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates | null>(null)
  const baseCurrency = "USD"

  useEffect(() => {
    fetch(`/api/exchange-rates?base=${baseCurrency}`)
      .then((res) => res.json())
      .then((data) => setExchangeRates(data))
      .catch((err) => console.error("Failed to fetch exchange rates:", err))
  }, [baseCurrency])

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "secondary"
    }
  }

  const getApprovalProgress = (expense: any) => {
    if (!expense.expense_approvals || expense.expense_approvals.length === 0) {
      return "No approvals required"
    }

    const approved = expense.expense_approvals.filter((a: any) => a.status === "approved").length
    const total = expense.expense_approvals.length

    return `${approved}/${total} approved`
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Expense History</CardTitle>
          <CardDescription>View all your submitted expenses and their approval status</CardDescription>
        </CardHeader>
        <CardContent>
          {expenses.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No expenses submitted yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Approval Progress</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expenses.map((expense) => (
                  <TableRow key={expense.id}>
                    <TableCell>{formatDate(expense.expense_date)}</TableCell>
                    <TableCell className="font-medium">
                      {formatCurrencyWithConversion(expense.amount, expense.currency, baseCurrency, exchangeRates)}
                    </TableCell>
                    <TableCell>{expense.expense_categories?.name || "N/A"}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(expense.status)}>{expense.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">{getApprovalProgress(expense)}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => setSelectedExpense(expense)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {selectedExpense && (
        <ExpenseDetailsDialog
          open={!!selectedExpense}
          onOpenChange={(open) => !open && setSelectedExpense(null)}
          expense={selectedExpense}
        />
      )}
    </>
  )
}
