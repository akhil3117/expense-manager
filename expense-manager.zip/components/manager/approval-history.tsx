"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { formatDate } from "@/lib/utils"
import { useEffect, useState } from "react"
import { formatCurrencyWithConversion, type ExchangeRates } from "@/lib/currency"

interface ApprovalHistoryProps {
  approvals: any[]
}

export function ApprovalHistory({ approvals }: ApprovalHistoryProps) {
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates | null>(null)
  const baseCurrency = "USD"

  useEffect(() => {
    fetch(`/api/exchange-rates?base=${baseCurrency}`)
      .then((res) => res.json())
      .then((data) => setExchangeRates(data))
      .catch((err) => console.error("Failed to fetch exchange rates:", err))
  }, [baseCurrency])

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "secondary"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Approval History</CardTitle>
        <CardDescription>All expenses you have reviewed</CardDescription>
      </CardHeader>
      <CardContent>
        {approvals.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No approval history yet</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Expense Date</TableHead>
                <TableHead>Your Decision</TableHead>
                <TableHead>Decision Date</TableHead>
                <TableHead>Comments</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {approvals.map((approval) => (
                <TableRow key={approval.id}>
                  <TableCell className="font-medium">
                    {approval.expenses?.profiles?.full_name || approval.expenses?.profiles?.email || "N/A"}
                  </TableCell>
                  <TableCell>
                    {formatCurrencyWithConversion(
                      approval.expenses?.amount || 0,
                      approval.expenses?.currency || "USD",
                      baseCurrency,
                      exchangeRates,
                    )}
                  </TableCell>
                  <TableCell>{approval.expenses?.expense_categories?.name || "N/A"}</TableCell>
                  <TableCell>{formatDate(approval.expenses?.expense_date || new Date())}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(approval.status)}>{approval.status}</Badge>
                  </TableCell>
                  <TableCell>{approval.approved_at ? formatDate(approval.approved_at) : "-"}</TableCell>
                  <TableCell className="max-w-xs truncate">{approval.comments || "-"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
