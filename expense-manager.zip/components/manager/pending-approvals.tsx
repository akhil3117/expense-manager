"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle2, XCircle } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { useState, useEffect } from "react"
import { ApprovalDialog } from "./approval-dialog"
import { formatCurrencyWithConversion, type ExchangeRates } from "@/lib/currency"

interface PendingApprovalsProps {
  approvals: any[]
  approvalRules: any[]
}

export function PendingApprovals({ approvals, approvalRules }: PendingApprovalsProps) {
  const [selectedApproval, setSelectedApproval] = useState<any>(null)
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null)
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates | null>(null)
  const baseCurrency = "USD"

  useEffect(() => {
    fetch(`/api/exchange-rates?base=${baseCurrency}`)
      .then((res) => res.json())
      .then((data) => setExchangeRates(data))
      .catch((err) => console.error("Failed to fetch exchange rates:", err))
  }, [baseCurrency])

  const handleAction = (approval: any, action: "approve" | "reject") => {
    setSelectedApproval(approval)
    setActionType(action)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals</CardTitle>
          <CardDescription>Review and approve or reject expense requests</CardDescription>
        </CardHeader>
        <CardContent>
          {approvals.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No pending approvals</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {approvals.map((approval) => (
                  <TableRow key={approval.id}>
                    <TableCell className="font-medium">
                      {approval.expenses?.profiles?.full_name || approval.expenses?.profiles?.email || "N/A"}
                    </TableCell>
                    <TableCell>
                      {formatCurrencyWithConversion(
                        approval.expenses?.amount || 0,
                        approval.expenses?.currency || "USD",
                        baseCurrency,
                        exchangeRates,
                      )}
                    </TableCell>
                    <TableCell>{approval.expenses?.expense_categories?.name || "N/A"}</TableCell>
                    <TableCell>{formatDate(approval.expenses?.expense_date || new Date())}</TableCell>
                    <TableCell>
                      {approval.is_manager_approval ? (
                        <Badge variant="outline">Manager</Badge>
                      ) : (
                        <Badge variant="secondary">Step {approval.sequence_order}</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleAction(approval, "approve")}>
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleAction(approval, "reject")}>
                          <XCircle className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {selectedApproval && actionType && (
        <ApprovalDialog
          open={!!selectedApproval}
          onOpenChange={(open) => {
            if (!open) {
              setSelectedApproval(null)
              setActionType(null)
            }
          }}
          approval={selectedApproval}
          actionType={actionType}
          approvalRules={approvalRules}
        />
      )}
    </>
  )
}
