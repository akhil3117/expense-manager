"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { formatDate, formatCurrency } from "@/lib/utils"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { FileText } from "lucide-react"

interface ApprovalDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  approval: any
  actionType: "approve" | "reject"
  approvalRules: any[]
}

export function ApprovalDialog({ open, onOpenChange, approval, actionType, approvalRules }: ApprovalDialogProps) {
  const [comments, setComments] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const expense = approval.expenses

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      // Update the approval record
      const { error: approvalError } = await supabase
        .from("expense_approvals")
        .update({
          status: actionType === "approve" ? "approved" : "rejected",
          comments,
          approved_at: new Date().toISOString(),
        })
        .eq("id", approval.id)

      if (approvalError) throw approvalError

      // Check if this approval affects the overall expense status
      const { data: allApprovals } = await supabase.from("expense_approvals").select("*").eq("expense_id", expense.id)

      if (allApprovals) {
        let newExpenseStatus = expense.status

        // If rejected, mark expense as rejected
        if (actionType === "reject") {
          newExpenseStatus = "rejected"
        } else {
          // Check approval rules
          const hasSpecificApproverRule = approvalRules.some(
            (rule) => rule.rule_type === "specific_approver" && rule.specific_approver_id === approval.approver_id,
          )

          if (hasSpecificApproverRule) {
            // If this is a specific approver who can auto-approve, mark as approved
            newExpenseStatus = "approved"
          } else {
            // Check percentage rules
            const percentageRule = approvalRules.find((rule) => rule.rule_type === "percentage")
            if (percentageRule) {
              const approvedCount = allApprovals.filter((a) => a.status === "approved").length
              const totalCount = allApprovals.length
              const approvalPercentage = (approvedCount / totalCount) * 100

              if (approvalPercentage >= percentageRule.percentage_threshold) {
                newExpenseStatus = "approved"
              }
            } else {
              // Sequential approval - check if all are approved
              const allApproved = allApprovals.every((a) => a.status === "approved")
              if (allApproved) {
                newExpenseStatus = "approved"
              }
            }
          }
        }

        // Update expense status if changed
        if (newExpenseStatus !== expense.status) {
          await supabase.from("expenses").update({ status: newExpenseStatus }).eq("id", expense.id)
        }
      }

      onOpenChange(false)
      router.refresh()
    } catch (error: any) {
      alert("Error processing approval: " + error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{actionType === "approve" ? "Approve" : "Reject"} Expense Request</DialogTitle>
          <DialogDescription>Review the expense details before making your decision</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Expense Details */}
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Employee</p>
              <p className="text-base font-medium">{expense?.profiles?.full_name || expense?.profiles?.email}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Amount</p>
              <p className="text-base font-bold">{formatCurrency(expense?.amount || 0, expense?.currency || "USD")}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Category</p>
              <p className="text-base">{expense?.expense_categories?.name || "N/A"}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Date</p>
              <p className="text-base">{formatDate(expense?.expense_date || new Date())}</p>
            </div>
          </div>

          {expense?.description && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">Description</p>
              <p className="text-base">{expense.description}</p>
            </div>
          )}

          {expense?.receipt_url && (
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2">Receipt</p>
              <a
                href={expense.receipt_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-sm text-primary hover:underline"
              >
                <FileText className="mr-2 h-4 w-4" />
                View Receipt
              </a>
            </div>
          )}

          <Separator />

          {/* Comments */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="comments">Comments {actionType === "reject" && "(Required)"}</Label>
              <Textarea
                id="comments"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder={
                  actionType === "approve"
                    ? "Add any comments (optional)..."
                    : "Please provide a reason for rejection..."
                }
                rows={3}
                required={actionType === "reject"}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading} variant={actionType === "approve" ? "default" : "destructive"}>
                {isLoading ? "Processing..." : actionType === "approve" ? "Approve Expense" : "Reject Expense"}
              </Button>
            </DialogFooter>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
