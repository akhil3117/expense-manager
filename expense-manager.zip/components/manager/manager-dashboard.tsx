"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PendingApprovals } from "./pending-approvals"
import { ApprovalHistory } from "./approval-history"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, Clock, XCircle } from "lucide-react"

interface ManagerDashboardProps {
  profile: any
  pendingApprovals: any[]
  allApprovals: any[]
  approvalRules: any[]
}

export function ManagerDashboard({ profile, pendingApprovals, allApprovals, approvalRules }: ManagerDashboardProps) {
  const approvedCount = allApprovals.filter((a) => a.status === "approved").length
  const rejectedCount = allApprovals.filter((a) => a.status === "rejected").length
  const pendingCount = pendingApprovals.length

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader profile={profile} />

      <main className="flex-1 p-6">
        <div className="mx-auto max-w-7xl space-y-6">
          <div>
            <h1 className="text-3xl font-bold">Manager Dashboard</h1>
            <p className="text-muted-foreground">Review and approve expense requests</p>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingCount}</div>
                <p className="text-xs text-muted-foreground">Awaiting your review</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Approved</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{approvedCount}</div>
                <p className="text-xs text-muted-foreground">Total approved by you</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Rejected</CardTitle>
                <XCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{rejectedCount}</div>
                <p className="text-xs text-muted-foreground">Total rejected by you</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="pending" className="space-y-6">
            <TabsList>
              <TabsTrigger value="pending">Pending ({pendingCount})</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="pending" className="space-y-4">
              <PendingApprovals approvals={pendingApprovals} approvalRules={approvalRules} />
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              <ApprovalHistory approvals={allApprovals} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
