// OCR utilities for extracting expense data from receipt images

export interface ReceiptData {
  merchant?: string
  amount?: number
  currency?: string
  date?: string
  category?: string
  items?: string[]
}

export async function extractReceiptData(imageUrl: string): Promise<ReceiptData> {
  try {
    const response = await fetch("/api/ocr/scan", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ imageUrl }),
    })

    if (!response.ok) {
      throw new Error("Failed to scan receipt")
    }

    return await response.json()
  } catch (error) {
    console.error("Error extracting receipt data:", error)
    throw error
  }
}
