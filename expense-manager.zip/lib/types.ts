export type UserRole = "admin" | "manager" | "employee"

export type ExpenseStatus = "pending" | "approved" | "rejected"

export type ApprovalStatus = "pending" | "approved" | "rejected"

export type RuleType = "percentage" | "specific_approver" | "hybrid"

export interface Company {
  id: string
  name: string
  currency: string
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  company_id: string
  email: string
  full_name: string | null
  role: UserRole
  manager_id: string | null
  is_manager_approver: boolean
  created_at: string
  updated_at: string
}

export interface ExpenseCategory {
  id: string
  company_id: string
  name: string
  created_at: string
}

export interface Expense {
  id: string
  company_id: string
  employee_id: string
  amount: number
  currency: string
  converted_amount: number | null
  category_id: string | null
  description: string | null
  expense_date: string
  receipt_url: string | null
  status: ExpenseStatus
  created_at: string
  updated_at: string
}

export interface ApprovalRule {
  id: string
  company_id: string
  name: string
  rule_type: RuleType
  percentage_threshold: number | null
  specific_approver_id: string | null
  is_active: boolean
  created_at: string
}

export interface ApprovalFlow {
  id: string
  company_id: string
  approver_id: string
  sequence_order: number
  created_at: string
}

export interface ApprovalRequest {
  id: string
  expense_id: string
  approver_id: string
  sequence_order: number
  status: ApprovalStatus
  comments: string | null
  approved_at: string | null
  created_at: string
}
