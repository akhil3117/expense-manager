// Currency conversion utilities using exchange rate API

const EXCHANGE_RATE_API = "https://api.exchangerate-api.com/v4/latest"

export interface ExchangeRates {
  base: string
  rates: Record<string, number>
  date: string
}

export async function getExchangeRates(baseCurrency = "USD"): Promise<ExchangeRates> {
  try {
    const response = await fetch(`${EXCHANGE_RATE_API}/${baseCurrency}`)
    if (!response.ok) {
      throw new Error("Failed to fetch exchange rates")
    }
    return await response.json()
  } catch (error) {
    console.error("Error fetching exchange rates:", error)
    throw error
  }
}

export function convertCurrency(
  amount: number,
  fromCurrency: string,
  toCurrency: string,
  rates: ExchangeRates,
): number {
  if (fromCurrency === toCurrency) {
    return amount
  }

  // If base currency matches fromCurrency, direct conversion
  if (rates.base === fromCurrency) {
    return amount * rates.rates[toCurrency]
  }

  // If base currency matches toCurrency, inverse conversion
  if (rates.base === toCurrency) {
    return amount / rates.rates[fromCurrency]
  }

  // Otherwise, convert through base currency
  const amountInBase = amount / rates.rates[fromCurrency]
  return amountInBase * rates.rates[toCurrency]
}

export function formatCurrencyWithConversion(
  amount: number,
  currency: string,
  baseCurrency: string,
  rates: ExchangeRates | null,
): string {
  const formatted = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency,
  }).format(amount)

  if (!rates || currency === baseCurrency) {
    return formatted
  }

  try {
    const convertedAmount = convertCurrency(amount, currency, baseCurrency, rates)
    const convertedFormatted = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: baseCurrency,
    }).format(convertedAmount)

    return `${formatted} (${convertedFormatted})`
  } catch (error) {
    return formatted
  }
}
