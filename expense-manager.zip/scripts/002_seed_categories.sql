-- Insert default expense categories for companies
-- This will be run after a company is created

-- Note: This is a template. Actual seeding will happen via the application
-- when a new company is created, using the company's ID

-- Example categories:
-- Travel, Meals, Office Supplies, Software, Equipment, Training, Other
