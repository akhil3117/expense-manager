-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Companies table
create table if not exists public.companies (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  currency text not null default 'USD',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Users/Profiles table (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid references public.companies(id) on delete cascade,
  email text not null,
  full_name text,
  role text not null check (role in ('admin', 'manager', 'employee')),
  manager_id uuid references public.profiles(id) on delete set null,
  is_manager_approver boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Expense categories
create table if not exists public.expense_categories (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  name text not null,
  created_at timestamp with time zone default now()
);

-- Expenses table
create table if not exists public.expenses (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  employee_id uuid references public.profiles(id) on delete cascade,
  amount numeric(10, 2) not null,
  currency text not null,
  converted_amount numeric(10, 2),
  category_id uuid references public.expense_categories(id) on delete set null,
  description text,
  expense_date date not null,
  receipt_url text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Approval rules table
create table if not exists public.approval_rules (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  name text not null,
  rule_type text not null check (rule_type in ('percentage', 'specific_approver', 'hybrid')),
  percentage_threshold integer check (percentage_threshold between 0 and 100),
  specific_approver_id uuid references public.profiles(id) on delete set null,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

-- Approval flow (defines the sequence of approvers)
create table if not exists public.approval_flows (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  approver_id uuid references public.profiles(id) on delete cascade,
  sequence_order integer not null,
  created_at timestamp with time zone default now(),
  unique(company_id, sequence_order)
);

-- Approval requests (tracks individual approval steps)
create table if not exists public.approval_requests (
  id uuid primary key default uuid_generate_v4(),
  expense_id uuid references public.expenses(id) on delete cascade,
  approver_id uuid references public.profiles(id) on delete cascade,
  sequence_order integer not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  comments text,
  approved_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

-- Enable Row Level Security
alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.expense_categories enable row level security;
alter table public.expenses enable row level security;
alter table public.approval_rules enable row level security;
alter table public.approval_flows enable row level security;
alter table public.approval_requests enable row level security;

-- RLS Policies for companies
create policy "Users can view their own company"
  on public.companies for select
  using (
    id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Admins can update their company"
  on public.companies for update
  using (
    id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for profiles
create policy "Users can view profiles in their company"
  on public.profiles for select
  using (
    company_id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Admins can insert profiles in their company"
  on public.profiles for insert
  with check (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

create policy "Admins can update profiles in their company"
  on public.profiles for update
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

create policy "Admins can delete profiles in their company"
  on public.profiles for delete
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for expense_categories
create policy "Users can view categories in their company"
  on public.expense_categories for select
  using (
    company_id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Admins can manage categories"
  on public.expense_categories for all
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for expenses
create policy "Users can view expenses in their company"
  on public.expenses for select
  using (
    company_id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Employees can insert their own expenses"
  on public.expenses for insert
  with check (auth.uid() = employee_id);

create policy "Employees can update their pending expenses"
  on public.expenses for update
  using (auth.uid() = employee_id and status = 'pending');

create policy "Managers and admins can update expenses"
  on public.expenses for update
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role in ('admin', 'manager')
    )
  );

-- RLS Policies for approval_rules
create policy "Users can view approval rules in their company"
  on public.approval_rules for select
  using (
    company_id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Admins can manage approval rules"
  on public.approval_rules for all
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for approval_flows
create policy "Users can view approval flows in their company"
  on public.approval_flows for select
  using (
    company_id in (
      select company_id from public.profiles where id = auth.uid()
    )
  );

create policy "Admins can manage approval flows"
  on public.approval_flows for all
  using (
    company_id in (
      select company_id from public.profiles 
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for approval_requests
create policy "Users can view approval requests in their company"
  on public.approval_requests for select
  using (
    expense_id in (
      select id from public.expenses 
      where company_id in (
        select company_id from public.profiles where id = auth.uid()
      )
    )
  );

create policy "Approvers can update their approval requests"
  on public.approval_requests for update
  using (auth.uid() = approver_id);

create policy "System can insert approval requests"
  on public.approval_requests for insert
  with check (true);
