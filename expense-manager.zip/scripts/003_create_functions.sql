-- Function to handle new user signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  new_company_id uuid;
  user_currency text;
begin
  -- Get currency from metadata or default to USD
  user_currency := coalesce(new.raw_user_meta_data ->> 'currency', 'USD');
  
  -- Create a new company for the first user (admin)
  insert into public.companies (name, currency)
  values (
    coalesce(new.raw_user_meta_data ->> 'company_name', 'My Company'),
    user_currency
  )
  returning id into new_company_id;

  -- Create profile for the new user as admin
  insert into public.profiles (
    id,
    company_id,
    email,
    full_name,
    role,
    is_manager_approver
  )
  values (
    new.id,
    new_company_id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    'admin',
    false
  );

  -- Create default expense categories
  insert into public.expense_categories (company_id, name)
  values
    (new_company_id, 'Travel'),
    (new_company_id, 'Meals & Entertainment'),
    (new_company_id, 'Office Supplies'),
    (new_company_id, 'Software & Subscriptions'),
    (new_company_id, 'Equipment'),
    (new_company_id, 'Training & Development'),
    (new_company_id, 'Other');

  return new;
end;
$$;

-- Trigger to create company and profile on user signup
drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- Function to create approval requests when expense is submitted
create or replace function public.create_approval_requests()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  employee_record record;
  flow_record record;
  request_sequence integer := 1;
begin
  -- Get employee details
  select * into employee_record
  from public.profiles
  where id = new.employee_id;

  -- Check if manager approval is required first
  if employee_record.is_manager_approver and employee_record.manager_id is not null then
    insert into public.approval_requests (
      expense_id,
      approver_id,
      sequence_order,
      status
    )
    values (
      new.id,
      employee_record.manager_id,
      request_sequence,
      'pending'
    );
    request_sequence := request_sequence + 1;
  end if;

  -- Create approval requests based on approval flow
  for flow_record in
    select * from public.approval_flows
    where company_id = new.company_id
    order by sequence_order
  loop
    insert into public.approval_requests (
      expense_id,
      approver_id,
      sequence_order,
      status
    )
    values (
      new.id,
      flow_record.approver_id,
      request_sequence,
      'pending'
    );
    request_sequence := request_sequence + 1;
  end loop;

  return new;
end;
$$;

-- Trigger to create approval requests on expense insert
drop trigger if exists on_expense_created on public.expenses;

create trigger on_expense_created
  after insert on public.expenses
  for each row
  execute function public.create_approval_requests();
