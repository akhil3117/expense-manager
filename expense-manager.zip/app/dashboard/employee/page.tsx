import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { EmployeeDashboard } from "@/components/employee/employee-dashboard"

export default async function EmployeePage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*, companies(*)").eq("id", data.user.id).single()

  if (!profile || profile.role === "admin") {
    redirect("/dashboard")
  }

  // Get expense categories
  const { data: categories } = await supabase
    .from("expense_categories")
    .select("*")
    .eq("company_id", profile.company_id)

  // Get user's expenses with approval details
  const { data: expenses } = await supabase
    .from("expenses")
    .select(`
      *,
      expense_categories(*),
      expense_approvals(
        *,
        profiles(*)
      )
    `)
    .eq("employee_id", data.user.id)
    .order("created_at", { ascending: false })

  return <EmployeeDashboard profile={profile} categories={categories || []} expenses={expenses || []} />
}
