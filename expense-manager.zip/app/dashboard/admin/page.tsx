import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default async function AdminPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*, companies(*)").eq("id", data.user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  // Get all users in the company
  const { data: users } = await supabase
    .from("profiles")
    .select("*")
    .eq("company_id", profile.company_id)
    .order("created_at", { ascending: false })

  // Get expense categories
  const { data: categories } = await supabase
    .from("expense_categories")
    .select("*")
    .eq("company_id", profile.company_id)

  // Get approval flows
  const { data: approvalFlows } = await supabase
    .from("approval_flows")
    .select("*, profiles(*)")
    .eq("company_id", profile.company_id)
    .order("sequence_order", { ascending: true })

  // Get approval rules
  const { data: approvalRules } = await supabase
    .from("approval_rules")
    .select("*, profiles(*)")
    .eq("company_id", profile.company_id)

  // Get all expenses for overview
  const { data: expenses } = await supabase
    .from("expenses")
    .select("*, profiles(*), expense_categories(*)")
    .eq("company_id", profile.company_id)
    .order("created_at", { ascending: false })
    .limit(10)

  return (
    <AdminDashboard
      profile={profile}
      users={users || []}
      categories={categories || []}
      approvalFlows={approvalFlows || []}
      approvalRules={approvalRules || []}
      expenses={expenses || []}
    />
  )
}
