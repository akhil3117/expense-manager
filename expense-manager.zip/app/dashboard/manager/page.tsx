import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ManagerDashboard } from "@/components/manager/manager-dashboard"

export default async function ManagerPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*, companies(*)").eq("id", data.user.id).single()

  if (!profile || (profile.role !== "manager" && profile.role !== "admin")) {
    redirect("/dashboard")
  }

  // Get pending approvals for this manager
  const { data: pendingApprovals } = await supabase
    .from("expense_approvals")
    .select(`
      *,
      expenses(
        *,
        profiles(*),
        expense_categories(*)
      )
    `)
    .eq("approver_id", data.user.id)
    .eq("status", "pending")
    .order("created_at", { ascending: false })

  // Get all expenses that need this manager's approval (including completed ones)
  const { data: allApprovals } = await supabase
    .from("expense_approvals")
    .select(`
      *,
      expenses(
        *,
        profiles(*),
        expense_categories(*)
      )
    `)
    .eq("approver_id", data.user.id)
    .order("created_at", { ascending: false })

  // Get approval rules to check for special conditions
  const { data: approvalRules } = await supabase
    .from("approval_rules")
    .select("*")
    .eq("company_id", profile.company_id)
    .eq("is_active", true)

  return (
    <ManagerDashboard
      profile={profile}
      pendingApprovals={pendingApprovals || []}
      allApprovals={allApprovals || []}
      approvalRules={approvalRules || []}
    />
  )
}
