import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Receipt, Users, TrendingUp, Shield } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="flex flex-1 flex-col items-center justify-center px-6 py-24 text-center">
        <div className="mx-auto max-w-3xl space-y-6">
          <h1 className="text-balance text-5xl font-bold tracking-tight sm:text-6xl">Expense Management Made Simple</h1>
          <p className="text-pretty text-lg text-muted-foreground sm:text-xl">
            Streamline your expense approval process with automated workflows, multi-level approvals, and real-time
            tracking.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button asChild size="lg">
              <Link href="/auth/signup">Get Started</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/auth/login">Sign In</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="border-t bg-muted/50 px-6 py-24">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-12 text-center text-3xl font-bold">Everything you need to manage expenses</h2>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Receipt className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Easy Submission</h3>
              <p className="text-sm text-muted-foreground">
                Submit expenses with OCR receipt scanning and automatic data extraction
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Multi-Level Approval</h3>
              <p className="text-sm text-muted-foreground">
                Configure sequential approval flows with manager and admin oversight
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Smart Rules</h3>
              <p className="text-sm text-muted-foreground">
                Set percentage-based or specific approver rules for flexible workflows
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Role-Based Access</h3>
              <p className="text-sm text-muted-foreground">Secure permissions for admins, managers, and employees</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
