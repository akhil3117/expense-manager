import { NextResponse } from "next/server"
import { generateObject } from "ai"
import { z } from "zod"

const receiptSchema = z.object({
  merchant: z.string().optional().describe("The name of the merchant or vendor"),
  amount: z.number().optional().describe("The total amount on the receipt"),
  currency: z.string().optional().describe("The currency code (e.g., USD, EUR, GBP)"),
  date: z.string().optional().describe("The date of the transaction in YYYY-MM-DD format"),
  category: z.string().optional().describe("The expense category (e.g., Meals, Travel, Office Supplies)"),
  items: z.array(z.string()).optional().describe("List of items purchased"),
})

export async function POST(request: Request) {
  try {
    const { imageUrl } = await request.json()

    if (!imageUrl) {
      return NextResponse.json({ error: "Image URL is required" }, { status: 400 })
    }

    // Use AI to extract receipt data from the image
    const { object } = await generateObject({
      model: "openai/gpt-4o",
      schema: receiptSchema,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extract the receipt information from this image. Identify the merchant name, total amount, currency, date, and suggest an appropriate expense category. If you can see individual items, list them as well.",
            },
            {
              type: "image",
              image: imageUrl,
            },
          ],
        },
      ],
    })

    return NextResponse.json(object)
  } catch (error: any) {
    console.error("OCR error:", error)
    return NextResponse.json({ error: "Failed to process receipt: " + error.message }, { status: 500 })
  }
}
